const loader=document.getElementById("loader");
window.addEventListener("load",()=>setTimeout(()=>loader.classList.add("done"),450));
const header=document.getElementById("header"),progress=document.getElementById("progress"),heroImage=document.getElementById("heroImage");
function onScroll(){
 const y=window.scrollY,max=document.documentElement.scrollHeight-innerHeight;
 progress.style.width=(max>0?y/max*100:0)+"%";
 header.classList.toggle("scrolled",y>35);
 if(heroImage && y<innerHeight*1.25){
   const p=Math.min(y/innerHeight,1);
   heroImage.style.transform=`scale(${1.18+p*.17}) translate3d(0,${p*45}px,0)`;
 }
}
window.addEventListener("scroll",onScroll,{passive:true});onScroll();
const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("nav");
menuBtn.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuBtn.setAttribute("aria-expanded",String(open));});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menuBtn.setAttribute("aria-expanded","false");}));
const revealObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("visible");revealObserver.unobserve(entry.target);}}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>revealObserver.observe(el));
const parallaxObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("in-view");}}),{threshold:.05});
document.querySelectorAll(".parallax-img").forEach(img=>parallaxObserver.observe(img));
const lightbox=document.getElementById("lightbox"),lightboxImage=document.getElementById("lightboxImage");
document.querySelectorAll(".gallery-card").forEach(card=>card.addEventListener("click",()=>{lightboxImage.src=card.dataset.image;lightbox.classList.add("open");lightbox.setAttribute("aria-hidden","false");}));
function closeLightbox(){lightbox.classList.remove("open");lightbox.setAttribute("aria-hidden","true");}
document.getElementById("lightboxClose").addEventListener("click",closeLightbox);
lightbox.addEventListener("click",e=>{if(e.target===lightbox)closeLightbox();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeLightbox();});
