# DPS Azaad Nagar — Complete Cinematic Website Prototype

## What's included
- Responsive single-page school website
- Cinematic aerial-photo hero with scroll zoom/parallax
- Scroll reveal animations and reading-progress bar
- Mobile navigation
- Campus, academics, school life, reception, leadership, gallery and admissions sections
- Click-to-expand gallery images
- Official-site links for admissions and contact
- Supplied campus/reception/leadership images cropped from the screenshots provided in the conversation

## Run the website
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Install/use the Live Server extension (optional but recommended).
4. Right-click `index.html` → Open with Live Server.

No npm install or build command is required.

## Before official publication
This is an independent prototype, not an authorised official website.
- Obtain written approval from the school administration and the domain/website owner before publishing or replacing any official site.
- Replace screenshot-derived photos with original, high-resolution school-approved image/video files. The hero is an animated still-image effect, not real drone footage.
- Confirm image ownership and permissions, including the leadership photograph and any identifiable people.
- Have the school verify every statement, class range, admission link, contact detail and policy.
- Add forms only through a school-approved, secure system with appropriate privacy notices and safeguards.
- Test on real phones, tablets and desktops; optimise image sizes and accessibility before launch.

## External links used
- https://dpsazaadnagar.com/
- https://dpsazaadnagar.com/admissions/
- https://dpsazaadnagar.com/apply-now/
- https://dpsazaadnagar.com/campus-facilities/
- https://dpsazaadnagar.com/contact-azaad-nagar/

The existing official website and school administration should be treated as the source of truth for current information.
